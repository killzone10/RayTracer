#include "translate.h"

Translate::Translate(math::vec3<double> translate):translate{translate}{};
