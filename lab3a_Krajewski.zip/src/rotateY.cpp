#include "rotateY.h"

RotateY::RotateY(int theta):theta{theta}{};
