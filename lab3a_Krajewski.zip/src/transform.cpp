#include "transform.h"

void Transform::print(){
    std::cout<<"udalo sie !" <<std::endl;
}