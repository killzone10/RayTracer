#include "rotateZ.h"

RotateZ::RotateZ(int theta):theta{theta}{};
