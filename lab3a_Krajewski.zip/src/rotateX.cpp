#include "rotateX.h"

RotateX::RotateX(int theta):theta{theta}{};
