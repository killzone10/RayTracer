#include "ambientLight.h"

ambientLight:: ambientLight(math::vec3<double> color) : Light(color, 0){};