#include "scale.h"

Scale::Scale(math::vec3<double> scale):scale{scale}{};
